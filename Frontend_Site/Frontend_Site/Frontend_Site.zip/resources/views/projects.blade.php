@extends('layouts.app')

@section('title', 'Projects')

@section('content')

     @include('Components.ProjectPageTopBanner')
     @include('Components.AllProjects')
      
@endsection