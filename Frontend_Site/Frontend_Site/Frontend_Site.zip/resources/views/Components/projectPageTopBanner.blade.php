<div class="container-fluid jumbotron mt-5 top-banner_parallax">
    <div class="row d-flex justify-content-center">
        <div class="col-md-6  text-center">
            <img class=" page-top-img fadeIn pt-5 mt-5" src="images/code.svg">
            <h1 class="page-top-title mt-3">- প্রজেক্ট সমূহ -</h1>
        </div>
    </div>
</div>