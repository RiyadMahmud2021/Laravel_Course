<div class="container-fluid top-banner_parallax jumbotron mt-5 ">
    <div class="row d-flex justify-content-center ">
        <div class="col-md-6  text-center">
            <img class=" page-top-img fadeIn pt-5 mt-5" src="images/knowledge.svg">
            <h1 class="page-top-title mt-3">- অনলাইন কোর্স সমূহ -</h1>
        </div>
    </div>
</div>

