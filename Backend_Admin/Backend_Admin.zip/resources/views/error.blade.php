@extends('layouts.app')
@section('title','Error')

@section('content')
<div id="wrongDiv" class="container  mt-5">
    <div class="row">
        <div class="col-md-12 mt-5 p-5 text-center ">
            <h2>Sorry, Something Went Wrong! See database connection! (try and catch)</h2>  
            <!-- <h2> <?php //echo $e;?> </h2>  -->
        </div>
    </div>
</div>
@endsection 